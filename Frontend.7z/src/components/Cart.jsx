import React from 'react';

function Cart() {
  return (
    <div className="p-6">
      {/* Cart Items Display */}
      <h3 className="text-xl font-semibold">Cart</h3>
    </div>
  );
}

export default Cart;
